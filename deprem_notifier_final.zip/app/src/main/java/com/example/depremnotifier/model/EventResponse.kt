package com.example.depremnotifier.model

data class EventResponse(
    val data: List<Earthquake>
)