package com.example.depremnotifier.ui

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.depremnotifier.DepremRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val channelId = "deprem_alert_channel"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createNotificationChannel()
        checkEarthquakes()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Deprem Uyarıları"
            val descriptionText = "Büyük depremler için bildirimler alın"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun checkEarthquakes() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val quakes = DepremRepository().fetchRecentEarthquakes(4.0)
                if (quakes.isNotEmpty()) {
                    val quake = quakes.first()
                    notifyUser(quake)
                } else {
                    Toast.makeText(this@MainActivity, "Son 24 saatte büyük deprem bulunamadı", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Veri alınırken hata: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun notifyUser(quake: Any) {
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_earthquake)
            .setContentTitle("Deprem: ${quake.magnitude} Mw")
            .setContentText("${quake.location}, ${quake.eventDate}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        with(NotificationManagerCompat.from(this)) {
            notify(1001, builder.build())
        }
    }
}