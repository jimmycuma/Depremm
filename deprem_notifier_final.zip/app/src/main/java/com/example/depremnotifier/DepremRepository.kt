package com.example.depremnotifier

import com.example.depremnotifier.model.Earthquake
import com.example.depremnotifier.network.FilterItem
import com.example.depremnotifier.network.FilterRequest
import com.example.depremnotifier.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

class DepremRepository {
    suspend fun fetchRecentEarthquakes(minMagnitude: Double = 4.0): List<Earthquake> = withContext(Dispatchers.IO) {
        val now = LocalDateTime.now(ZoneOffset.UTC)
        val yesterday = now.minusDays(1)
        val formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME

        val filters = listOf(
            FilterItem(8, yesterday.format(formatter)),
            FilterItem(9, now.format(formatter))
        )
        val response = RetrofitClient.apiService.getEvents(FilterRequest(filters))
        response.data.filter { it.magnitude >= minMagnitude }
    }
}