package com.example.depremnotifier.network

import com.example.depremnotifier.model.EventResponse
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

data class FilterItem(val FilterType: Int, val Value: String)

data class FilterRequest(
    val EventSearchFilterList: List<FilterItem>,
    val Skip: Int = 0,
    val Take: Int = 50,
    val SortDescriptor: Map<String, String> = mapOf("field" to "eventDate", "dir" to "desc")
)

interface AfadApiService {
    @Headers("Content-Type: application/json")
    @POST("EventData/GetEventsByFilter")
    suspend fun getEvents(@Body filter: FilterRequest): EventResponse
}