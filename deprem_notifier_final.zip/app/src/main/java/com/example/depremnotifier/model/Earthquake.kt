package com.example.depremnotifier.model

data class Earthquake(
    val id: Int,
    val eventDate: String,
    val latitude: Double,
    val longitude: Double,
    val depth: Double,
    val magnitude: Double,
    val location: String
)